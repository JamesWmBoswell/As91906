from django.contrib import admin
from .models import Book, Catagory, Register

# Register your models here.

# Adds the models to the admin page
admin.site.register(Book)
admin.site.register(Catagory)
admin.site.register(Register)