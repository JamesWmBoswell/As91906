from django.contrib import admin
from .models import Book

# Register your models here.

# Adds the models to the admin page
admin.site.register(Book)