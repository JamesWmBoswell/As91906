from django.db import models

# Create your models here.

class Book(models.Model):
    Book_ID = models.AutoField(primary_key=True)
    Book_Name = models.CharField(max_length=50)
    Publish_Date = models.CharField(max_length=24)
    Author = models.CharField(max_length=50)
    Catagory = models.CharField(max_length=50)
    # Shows the chosen variables as the name 
    def __str__(self):
        return f"{self.Book_Name}, {self.Publish_Date}, {self.Author}"