from django.db import models
from django.core.exceptions import ValidationError

# Create your models here.

class Register (models.Model):
    User_Id = models.AutoField(primary_key=True)
    First_Name = models.CharField(max_length=50)
    Last_Name = models.CharField(max_length=50)
    Email = models.EmailField()

    def clean(self):
        if not self.First_Name.isalpha():
            raise ValidationError("First Name must only be letters.")
        if not self.Last_Name.isalpha():
            raise ValidationError("Last Name must only be letters.")
        if not self.Email.endswith("@school.nz"):
            raise ValidationError("Must end @school.nz.")  

    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.First_Name} {self.Last_Name}"

class Catagory (models.Model):
    Genre = models.CharField(max_length=50)
    Fiction = models.CharField(max_length=11)
    def __str__(self):
        return f"{self.Genre}, {self.Fiction}"

class Book (models.Model):
    Book_ID = models.AutoField(primary_key=True)
    Book_Name = models.CharField(max_length=50)
    Publish_Date = models.DateField()
    Author = models.CharField(max_length=50)
    Catagory = models.ForeignKey(Catagory, on_delete=models.CASCADE)
    Borrowed = models.BooleanField(default=False)
    def __str__(self):
        return f"{self.Book_Name}, {self.Author}"    

class Record (models.Model):
    Borrow_id = models.AutoField(primary_key=True)
    Student = models.ForeignKey(Register, on_delete=models.CASCADE)
    Book_ID = models.ForeignKey(Book, on_delete=models.CASCADE)
    Issue_date = models.DateField()
    Due_date = models.DateField()
    Return_date = models.DateField()
    def __str__(self):
        return f"{self.Student} Borrowed {self.Book_ID}"