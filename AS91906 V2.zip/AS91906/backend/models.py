from django.db import models

# Create your models here.


class Catagory (models.Model):
    Genre = models.CharField(max_length=50)
    fiction = models.CharField(max_length=11)
    def __str__(self):
        return f"{self.Genre}, {self.fiction}"

class Book (models.Model):
    Book_ID = models.AutoField(primary_key=True)
    Book_Name = models.CharField(max_length=50)
    Publish_Date = models.DateField()
    Author = models.CharField(max_length=50)
    Catagory = models.ForeignKey(Catagory, on_delete=models.CASCADE)
    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.Book_Name}, {self.Author}, {self.Publish_Date}"
