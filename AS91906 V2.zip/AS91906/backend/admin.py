from django.contrib import admin
from .models import Book
from .models import Catagory

# Register your models here.

# Adds the models to the admin page
admin.site.register(Book)
admin.site.register(Catagory)